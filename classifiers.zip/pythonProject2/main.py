import pandas as pd
import zipfile
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt


zip_file = '/Users/jessicatran/Downloads/icpc17.zip'
comments = []

with zipfile.ZipFile(zip_file, 'r') as zip_ref:
    for file_name in zip_ref.namelist():
        if file_name.endswith('.txt'):
            with zip_ref.open(file_name) as f:
                try:
                    content = f.read().decode('utf-8')
                except UnicodeDecodeError:
                    content = f.read().decode('ISO-8859-1')

                label = 'ContentConcerns' if 'concerns.txt' in file_name else 'Miscellaneous'
                print(f"Processing file: {file_name}, Assigned label: {label}")
                comments.append((content.strip(), label))

df = pd.DataFrame(comments, columns=['comment', 'label'])
print(df.head())

label_encoder = LabelEncoder()
y = label_encoder.fit_transform(df['label'])

tfidf = TfidfVectorizer(stop_words='english', max_features=5000)
X = tfidf.fit_transform(df['comment'])

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Function to plot ROC curve
def plot_roc_curve(y_true, y_scores, label):
    fpr, tpr, _ = roc_curve(y_true, y_scores, pos_label='ContentConcerns')
    plt.plot(fpr, tpr, label=f'{label} (AUC = {roc_auc_score(y_true, y_scores):.2f})')

#Naive Bayes
nb_model = MultinomialNB()
nb_model.fit(X_train, y_train)
y_pred_nb = nb_model.predict(X_test)

nb_accuracy = accuracy_score(y_test, y_pred_nb)
nb_precision = precision_score(y_test, y_pred_nb, pos_label=1, zero_division=0)
nb_recall = recall_score(y_test, y_pred_nb, pos_label=1, zero_division=0)
nb_f1 = f1_score(y_test, y_pred_nb, pos_label=1, zero_division=0)

print(f"Naive Bayes - Accuracy: {nb_accuracy}, Precision: {nb_precision}, Recall: {nb_recall}, F1: {nb_f1}")

#SMV
svm_model = SVC(kernel='linear', class_weight='balanced')
svm_model.fit(X_train, y_train)
y_pred_svm = svm_model.predict(X_test)

svm_accuracy = accuracy_score(y_test, y_pred_svm)
svm_precision = precision_score(y_test, y_pred_svm, pos_label=1, zero_division=0)
svm_recall = recall_score(y_test, y_pred_svm, pos_label=1, zero_division=0)
svm_f1 = f1_score(y_test, y_pred_svm, pos_label=1, zero_division=0)

print(f"SVM - Accuracy: {svm_accuracy}, Precision: {svm_precision}, Recall: {svm_recall}, F1: {svm_f1}")

#Decision Tree
dt_model = DecisionTreeClassifier(random_state=42, class_weight='balanced')
dt_model.fit(X_train, y_train)
y_pred_dt = dt_model.predict(X_test)

dt_accuracy = accuracy_score(y_test, y_pred_dt)
dt_precision = precision_score(y_test, y_pred_dt, pos_label=1, zero_division=0)
dt_recall = recall_score(y_test, y_pred_dt, pos_label=1, zero_division=0)
dt_f1 = f1_score(y_test, y_pred_dt, pos_label=1, zero_division=0)

print(f"Decision Tree - Accuracy: {dt_accuracy}, Precision: {dt_precision}, Recall: {dt_recall}, F1: {dt_f1}")

#Random Forest
rf_model = RandomForestClassifier(random_state=42, class_weight='balanced')
rf_model.fit(X_train, y_train)
y_pred_rf = rf_model.predict(X_test)

rf_accuracy = accuracy_score(y_test, y_pred_rf)
rf_precision = precision_score(y_test, y_pred_rf, pos_label=1, zero_division=0)
rf_recall = recall_score(y_test, y_pred_rf, pos_label=1, zero_division=0)
rf_f1 = f1_score(y_test, y_pred_rf, pos_label=1, zero_division=0)

print(f"Random Forest - Accuracy: {rf_accuracy}, Precision: {rf_precision}, Recall: {rf_recall}, F1: {rf_f1}")

#10-fold cross validation
nb_cv_accuracy = cross_val_score(nb_model, X, y, cv=10, scoring='accuracy')
nb_cv_precision = cross_val_score(nb_model, X, y, cv=10, scoring='precision')
nb_cv_recall = cross_val_score(nb_model, X, y, cv=10, scoring='recall')
nb_cv_f1 = cross_val_score(nb_model, X, y, cv=10, scoring='f1')

print(f"Naive Bayes - 10-fold CV Accuracy: {nb_cv_accuracy.mean()}, Precision: {nb_cv_precision.mean()}, Recall: {nb_cv_recall.mean()}, F1: {nb_cv_f1.mean()}")

# Plot ROC curve
plt.figure()
plt.title('Receiver Operating Characteristic (ROC) Curve')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.legend(loc='lower right')
plt.plot([0, 1], [0, 1], 'k--')  # Diagonal line
plt.grid()
plt.show()