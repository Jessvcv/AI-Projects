import zipfile
import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

# Movie Recommender 2.0
# Load ratings and movie data from the ZIP file
zip_file = '/Users/jessicatran/Downloads/ml-100k.zip'
reviews = []
movies_data = []

# Extract data from the ZIP file
with zipfile.ZipFile(zip_file, 'r') as zip_ref:
    for file_name in zip_ref.namelist():
        # Load ratings data
        if file_name.endswith('.data'):
            with zip_ref.open(file_name) as f:
                content = f.read().decode('ISO-8859-1')
                for line in content.strip().split('\n'):
                    user_id, movie_id, rating, _ = line.split('\t')
                    reviews.append((int(user_id), int(movie_id), float(rating)))
        # Load movie information with genres
        elif file_name.endswith('u.item'):
            with zip_ref.open(file_name) as f:
                content = f.read().decode('ISO-8859-1')
                for line in content.strip().split('\n'):
                    parts = line.split('|')
                    movie_id, title = int(parts[0]), parts[1]
                    genres = list(map(int, parts[5:]))  # Genres are binary flags starting from index 5
                    movies_data.append((movie_id, title, genres))

# Create DataFrames for ratings and movies
data = pd.DataFrame(reviews, columns=['userId', 'movieId', 'rating'])
movies_with_genres = pd.DataFrame(movies_data, columns=['movieId', 'title', 'genres'])

# Create Matrix
matrix = data.pivot_table(index='userId', columns='movieId', values='rating').fillna(0)

# Random User
random_user_id = np.random.choice(matrix.index)
print(f"Randomly selected user: {random_user_id}")

# Calculate User Similarity
user_similarity = cosine_similarity(matrix)
similarity_df = pd.DataFrame(user_similarity, index=matrix.index, columns=matrix.index)

# Get similar users sorted by similarity score
similar_users = similarity_df[random_user_id].sort_values(ascending=False).drop(random_user_id)

# Generate Initial Recommendations & get movies the user hasn't rated
user_ratings = matrix.loc[random_user_id]
unrated_movies = user_ratings[user_ratings == 0].index

# Similar user ratings and weighted ratings
similar_users_ratings = matrix.loc[similar_users.index]
similarity_scores = np.array(similar_users.values).reshape(-1, 1)
weighted_ratings = (similar_users_ratings * similarity_scores).sum(axis=0) / similarity_scores.sum()

# gets movies the user has not rated
recommended_scores = weighted_ratings[unrated_movies]
top_10_movies = recommended_scores.sort_values(ascending=False).head(10)

# Calculate User's Genre Preferences & filters through movies the user has rated and merge with genre data
user_watched_movies = data[data['userId'] == random_user_id]
user_watched_with_genres = user_watched_movies.merge(movies_with_genres, on='movieId')

# Count movies watched per genre and normalize
genre_counts = np.sum(np.vstack(user_watched_with_genres['genres']), axis=0)
normalized_genre_counts = genre_counts / genre_counts.sum()

# Recommended movies with genre preference
recommended_with_genres = top_10_movies.reset_index().merge(movies_with_genres, on='movieId')

# Re-ranking using genre preferences
adjusted_scores = []
for _, row in recommended_with_genres.iterrows():
    genre_weight = np.dot(normalized_genre_counts, row['genres'])
    adjusted_score = row[0] * genre_weight
    adjusted_scores.append((row['movieId'], row['title'], adjusted_score))

# Sort and display the final top 10 recommendations with adjusted scores
final_recommendations = sorted(adjusted_scores, key=lambda x: x[2], reverse=True)[:10]

# Print results
print("Top 10 Genre-Adjusted Recommended Movies for User", random_user_id, ":")
for movie_id, title, score in final_recommendations:
    print(f"{title} (Score: {score:.4f})")
