import zipfile
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans

# Movie Recommender 1.5
# Load ratings and movie data from the ZIP file
zip_file = '/Users/jessicatran/Downloads/ml-100k.zip'
reviews = []
movies_data = []

# Extract data from the ZIP file
with zipfile.ZipFile(zip_file, 'r') as zip_ref:
    for file_name in zip_ref.namelist():
        # Load ratings data
        if file_name.endswith('.data'):
            with zip_ref.open(file_name) as f:
                content = f.read().decode('ISO-8859-1')
                for line in content.strip().split('\n'):
                    user_id, movie_id, rating, _ = line.split('\t')
                    reviews.append((int(user_id), int(movie_id), float(rating)))
        # Load movie information
        elif file_name.endswith('u.item'):
            with zip_ref.open(file_name) as f:
                content = f.read().decode('ISO-8859-1')
                for line in content.strip().split('\n'):
                    parts = line.split('|')
                    movie_id, title = int(parts[0]), parts[1]
                    movies_data.append((movie_id, title))

# Create DataFrames for ratings and movies
df_base = pd.DataFrame(reviews, columns=['userId', 'movieId', 'rating'])
movies = pd.DataFrame(movies_data, columns=['movieId', 'title'])

# Create Matrix
user_movie_matrix = df_base.pivot_table(index='userId', columns='movieId', values='rating').fillna(0)

# Random User
random_user_id = np.random.choice(user_movie_matrix.index)
print(f"Randomly selected user: {random_user_id}")

# Apply KMeans Clustering
num_clusters = 10  # You can adjust the number of clusters as needed
kmeans = KMeans(n_clusters=num_clusters, random_state=42)
user_clusters = kmeans.fit_predict(user_movie_matrix)

# Find Cluster Members and Watched Movies
user_cluster = user_clusters[random_user_id - 1]
cluster_users = np.where(user_clusters == user_cluster)[0]

# Get watched movies by user
watched_movies = user_movie_matrix.loc[random_user_id]
watched_movie_ids = watched_movies[watched_movies > 0].index

# Recommend Movies Not Watched by the Selected User
cluster_movie_ratings = user_movie_matrix.iloc[cluster_users].sum(axis=0)
unwatched_cluster_movies = cluster_movie_ratings[cluster_movie_ratings.index.difference(watched_movie_ids)]
top_10_recommendations = unwatched_cluster_movies.sort_values(ascending=False).head(10)

# Display Recommendations
recommended_movie_titles = movies[movies['movieId'].isin(top_10_recommendations.index)]['title']

print("Top 10 Cluster-Based Recommended Movies for User", random_user_id)
for title in recommended_movie_titles:
    print(title)


